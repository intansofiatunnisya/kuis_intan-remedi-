/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kuis_intan;

/**
 *
 * @author USER
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import kuis.db.DBHelper;

public class ovendatamodel {
    
    private final  Connection conn;

    public ovendatamodel () throws SQLException {
        this.conn =DBHelper.getConnection();
    }
    
    public void addovendatamodel(oven oven){
    String insertoven = "INSERT INTO oven ( `jenis`, `ukuran`, `tanggal_pembelian`, `harga`, `merk`)"
            + "VALUES ('"
            +oven.getJenis()+"','"
            +oven.getUkuran()+"','"
            +oven.getTanggal_pembelian()+"','"
            +oven.getHarga()+"','"
            +oven.getMerk()+"')";
    try {
    
    PreparedStatement Oven = (PreparedStatement) conn.prepareStatement(insertoven);
 
    Oven.execute();
    }
    catch(Exception e){
        System.out.println("eror "+e);
    }
    }

    void addoven(oven Oven) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}

