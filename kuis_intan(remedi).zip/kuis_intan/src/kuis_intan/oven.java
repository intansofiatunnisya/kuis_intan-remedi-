/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kuis_intan;

/**
 *
 * @author USER
 */
public class oven {
    
    private int  harga;
    private String jenis, ukuran, tanggal_pembelian, merk;

    public oven(int id, int harga, String jenis, String ukuran, String tanggal_pembelian, String merk) {
        
        this.harga = harga;
        this.jenis = jenis;
        this.ukuran = ukuran;
        this.tanggal_pembelian = tanggal_pembelian;
        this.merk = merk;
    }
    

   public oven() {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void setUkuran(String ukuran) {
        this.ukuran = ukuran;
    }


    public int getHarga() {
        return harga;
    }

    public void setHarga(int harga) {
        this.harga = harga;
    }

    public String getJenis() {
        return jenis;
    }

    public void setJenis(String jenis) {
        this.jenis = jenis;
    }

    

    public String getTanggal_pembelian() {
        return tanggal_pembelian;
    }

    public void setTanggal_pembelian(String Tanggal_pembelian) {
        this.tanggal_pembelian = tanggal_pembelian;
    }

    public String gettanggal_pembelian() {
        return tanggal_pembelian;
    }

    public void settanggal_pembelian(String tanggal_pembelian) {
        this.tanggal_pembelian = tanggal_pembelian;
    }

    public String getMerk() {
        return merk;
    }

    public void setMerk(String Merk) {
        this.merk = merk;
    }

    String getUkuran() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   
   
    
}

    

