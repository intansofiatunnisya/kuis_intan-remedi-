/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kuis_intan;

import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;

public class FXMLDocumentController {

    @FXML // ResourceBundle that was given to the FXMLLoader
    private ResourceBundle resources;

    @FXML // URL location of the FXML file that was given to the FXMLLoader
    private URL location;

    @FXML // fx:id="tf_ukuran"
    private TextField tf_ukuran; // Value injected by FXMLLoader

    @FXML // fx:id="tf_merk"
    private TextField tf_merk; // Value injected by FXMLLoader

    @FXML // fx:id="tf_harga"
    private TextField tf_harga; // Value injected by FXMLLoader

    @FXML // fx:id="btn_submit"
    private Button btn_submit; // Value injected by FXMLLoader

    @FXML // fx:id="dp_tanggal"
    private DatePicker dp_tanggal; // Value injected by FXMLLoader

    @FXML // fx:id="cb_jenis"
    private ComboBox<String> cb_jenis; // Value injected by FXMLLoader

    @FXML // This method is called by the FXMLLoader when initialization is complete
    void initialize() {
        assert tf_ukuran != null : "fx:id=\"tf_ukuran\" was not injected: check your FXML file 'FXMLDocument.fxml'.";
        assert tf_merk != null : "fx:id=\"tf_merk\" was not injected: check your FXML file 'FXMLDocument.fxml'.";
        assert tf_harga != null : "fx:id=\"tf_harga\" was not injected: check your FXML file 'FXMLDocument.fxml'.";
        assert btn_submit != null : "fx:id=\"btn_submit\" was not injected: check your FXML file 'FXMLDocument.fxml'.";
        assert dp_tanggal != null : "fx:id=\"dp_tanggal\" was not injected: check your FXML file 'FXMLDocument.fxml'.";
        assert cb_jenis != null : "fx:id=\"cb_jenis\" was not injected: check your FXML file 'FXMLDocument.fxml'.";

    }
    @FXML
   private void handleButtonAction(ActionEvent event) throws SQLException {
       
   
    ovendatamodel datamodel = new ovendatamodel();    
        
    oven Oven = new oven();
    Oven.setHarga(Integer.parseInt(tf_harga.getText()));
    Oven.setJenis(cb_jenis.getValue());
    Oven.setMerk(tf_merk.getText());
    Oven.setUkuran(tf_ukuran.getText());
    Oven.setTanggal_pembelian(dp_tanggal.getValue().toString());
    
    datamodel.addoven(Oven);
    
   }
  
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //TODO
    ArrayList <String> list = new ArrayList<String>();
    list.add("Oven Konvensional");
    list.add("Oven Gas");
    list.add("Oven Elektrik");
    list.add("Oven Konveksi");
    ObservableList items = FXCollections.observableArrayList(list);
    cb_jenis.setItems(items);

     }
       
    
}
